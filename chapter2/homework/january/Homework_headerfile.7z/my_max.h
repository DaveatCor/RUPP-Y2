float max(float a[], int n){
	float m = a[0];
	for(int i=0; i<n; i++){
		if(m<a[i])m = a[i];
	}
	return m;
}
