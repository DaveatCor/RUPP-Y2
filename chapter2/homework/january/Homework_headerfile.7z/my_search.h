int search(float a[], int n, float x){
	int index = -1;
	for(int i=0; i<n; i++){
		if (x==a[i]){
			index = i;
			break;
		}
	}
	return index; 
}
