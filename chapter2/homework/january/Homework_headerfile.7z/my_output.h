using namespace std;

void output(float a[], int n){
	for(int i=0; i<n; i++){
		cout<<a[i]<<"\t";
	}
}
