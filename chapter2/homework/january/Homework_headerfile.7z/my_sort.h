void sort(float a[], int n){
	float temp;
	for(int i = 0; i< n; i++){
		for (int j = i; j<n; j++){
			temp = a[i];
			if(a[i]>a[j]){
				a[i]=a[j];
				a[j]=temp;
			}
		}
	}
}
