// Date: 30/Jan/2021

#include<iostream>
#include<conio.h>
#include<my_input.h>
#include<my_output.h>
#include<my_sum.h>
#include<my_max.h>
#include<my_sort.h>
#include<my_search.h>

using namespace std;

int main(){
	float x[95], s1, max1, data; int n, pos;
	cout<<"Number of elements:"; cin>>n;
	cout<<"\nInput all elements:"<<endl;
	input(x, n);
	cout<<"\nOutput all elements: "<<endl;
	output(x, n);
	s1 = sum(x, n);
	cout<<"\nSum= "<<s1<<endl;
	max1 = max(x, n);
	cout<<"\nMax= "<<max1<<endl;
	cout<<"\nData to search: "; cin>>data;
	pos = search(x, n, data);
	cout<<"\nIndex: "<<pos;
	if (pos<0) cout<<"\nSearch not found:"<<endl;
	else x[pos]+=10;
	cout<< "\nAfter update: "<<endl;
	output(x, n);
	
	sort(x, n);
	cout<<"\n\nAfter sorting: "<<endl;
	output(x, n);
	getch();
}
