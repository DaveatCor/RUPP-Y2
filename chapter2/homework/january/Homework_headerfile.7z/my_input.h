using namespace std;

void input(float a[], int n){
	for(int i=0; i<n; i++){
		cout<<"Index: "; cin>>a[i];
	}
}

